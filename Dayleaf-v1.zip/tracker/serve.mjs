import http from 'node:http';
import https from 'node:https';
import {X509Certificate} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';

const root=path.dirname(fileURLToPath(import.meta.url));
const options = new Map();
for(let i=2;i<process.argv.length;i+=2) options.set(process.argv[i],process.argv[i+1]);
const host=options.get('--host')||'127.0.0.1', port=Number(options.get('--port')||4173);
const cert=options.get('--cert'),key=options.get('--key');
const caFile=options.get('--ca-only');
if(Boolean(cert)!==Boolean(key))throw Error('Specify both --cert and --key.');
if(!cert && !caFile && !['127.0.0.1','localhost','::1'].includes(host))throw Error('Use a trusted HTTPS certificate and key when serving to iPhone.');
const files=new Set(['index.html','style.css','app.js','icons.js','store.js','backup.js','settings.js','daily.js','daily.css','review.js','review.css','assess.js','assess.css','manifest.webmanifest','sw.js','forms/recent.pdf','forms/followup.pdf','forms/recent.png','forms/followup.png','forms/passages.js','assets/hills.webp','assets/icon-192.png','assets/icon-512.png','assets/touch.png']);
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.webmanifest':'application/manifest+json','.png':'image/png','.webp':'image/webp','.pdf':'application/pdf'};
async function serve(req,res){
  if(req.method!=='GET' && req.method!=='HEAD'){res.writeHead(405,{Allow:'GET, HEAD'}).end();return;}
  try{
    const route=new URL(req.url,'http://localhost').pathname.slice(1)||'index.html';
    if(!files.has(route)){res.writeHead(404).end();return;}
    const bytes=await readFile(path.join(root,route));
    res.writeHead(200,{'Content-Type':types[path.extname(route)],'Content-Length':bytes.length,'Cache-Control':'no-cache','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'});
    res.end(req.method==='HEAD'?undefined:bytes);
  }catch{res.writeHead(404).end();}
}
const server=cert?https.createServer({cert:await readFile(cert),key:await readFile(key)},serve):http.createServer(serve);
if(caFile){
  const ca=new X509Certificate(await readFile(caFile));
  if(!ca.ca)throw Error('Choose your local rootCA.pem certificate.');
  server.removeAllListeners('request');
  server.on('request',(req,res)=>{
    if(req.method!=='GET' || req.url!=='/root.cer'){res.writeHead(404).end();return;}
    res.writeHead(200,{'Content-Type':'application/x-x509-ca-cert','Cache-Control':'no-store','Content-Length':ca.raw.length}).end(ca.raw);
  });
  console.log('Public certificate SHA-256: '+ca.fingerprint256);
}
server.listen(port,host,()=>console.log('Dayleaf local server: '+(cert?'https':'http')+'://'+host+':'+server.address().port+(caFile?'/root.cer':'/')));

