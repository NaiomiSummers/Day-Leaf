export const stores = ['daily', 'meds', 'weekly', 'cssrs', 'workbook', 'settings'];
export const db = Object.fromEntries(stores.map(name => [name, []]));
const tables = stores;
const databaseName = 'dayleaf-journal-v1';
let connection;
let durableWrites = Promise.resolve();
let changeListener = () => {};
let onError = () => {};
let channel;
let revision = 0;

function done(tx) {
  return new Promise((resolve, reject) => {
    tx.oncomplete = resolve;
    tx.onabort = () => reject(tx.error || Error('The write was interrupted.'));
    tx.onerror = () => {};
  });
}
function result(req) {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
export async function openStore(onChange, onFailure) {
  changeListener = onChange;
  onError = onFailure;
  const req = indexedDB.open(databaseName, 1);
  req.onupgradeneeded = () => {
    for (const name of [...tables,'meta']) req.result.createObjectStore(name, {keyPath:'id'});
  };
  connection = await result(req);
  connection.onversionchange = () => { connection.close(); onError(Error('A newer journal is open. Reload this page.')); };
  const tx = connection.transaction([...stores,'meta']);
  const all = await Promise.all([...stores.map(s=>result(tx.objectStore(s).getAll())), result(tx.objectStore('meta').get('revision'))]);
  stores.forEach((name,i)=>{ db[name] = all[i]; });
  revision = all.at(-1)?.value || 0;
  if (typeof BroadcastChannel !== 'undefined') {
    channel = new BroadcastChannel(databaseName);
    channel.onmessage = () => onError(Error('Another window changed this journal. Reload this window before editing.'));
  }
}
function serial(operation) {
  const next = durableWrites.then(operation);
  durableWrites = next.catch(error => onError(error));
  return next;
}
function writeTransaction(names, mutate) {
  const tx = connection.transaction([...names,'meta'],'readwrite');
  let conflict = false;
  const finish = done(tx).catch(e => {throw conflict ? Error('Your journal changed in another window. Reload before editing.') : e;});
  const meta = tx.objectStore('meta');
  const req = meta.get('revision');
  req.onsuccess = () => {
    const current = req.result?.value || 0;
    if (current !== revision) { conflict = true; tx.abort(); return; }
    mutate(tx);
    meta.put({id:'revision',value:current+1});
  };
  return finish.then(()=>{revision++;channel?.postMessage('changed');});
}
export function put(name, record) {
  if (!stores.includes(name) || typeof record.id !== 'string' || !record.id) throw Error('Invalid record.');
  const list=db[name], index=list.findIndex(item=>item.id===record.id), old=list[index];
  const now=new Date().toISOString();
  const saved=structuredClone({...record,createdAt:old?.createdAt || now,updatedAt:now});
  if(index<0) list.push(saved); else list[index]=saved;
  return serial(async()=>{
    await writeTransaction([name],tx=>tx.objectStore(name).put(saved));
    changeListener(name);
    return saved;
  });
}
export function toBase64(bytes) {
  let text='';
  for(let i=0;i<bytes.length;i+=16384) text+=String.fromCharCode(...bytes.subarray(i,i+16384));
  return btoa(text);
}
export const fromBase64 = text => Uint8Array.from(atob(text), c=>c.charCodeAt(0));
export async function snapshot() {
  await durableWrites;
  const tx = connection.transaction(tables);
  const rows = await Promise.all(tables.map(name=>result(tx.objectStore(name).getAll())));
  const records=Object.fromEntries(stores.map((name,i)=>[name,rows[i]]));
  return {app:'Dayleaf',schema:1,exportedAt:new Date().toISOString(),records};
}
export function validateSnapshot(s) {
  const invalid=()=>{throw Error('This file does not contain a supported Dayleaf backup.');};
  if(s?.app!=='Dayleaf' || s.schema!==1 || !s.records || !Number.isFinite(Date.parse(s.exportedAt))) invalid();
  for(const name of stores) {
    const rows=s.records[name];
    if(!Array.isArray(rows)) invalid();
    const ids=new Set();
    for(const row of rows) {
      if(!row || typeof row.id!=='string' || !row.id || ids.has(row.id) || !Number.isFinite(Date.parse(row.createdAt)) || !Number.isFinite(Date.parse(row.updatedAt))) invalid();
      if(name!=='settings' && !/^\d{4}-\d{2}-\d{2}$/.test(row.date)) invalid();
      ids.add(row.id);
    }
  }
  return s;
}
export async function replaceAll(s) {
  validateSnapshot(s);
  await serial(()=>writeTransaction(tables,tx=>{
    for(const name of tables) {
      const table=tx.objectStore(name);
      table.clear();
      for(const row of s.records[name]) table.add(row);
    }
  }));
  stores.forEach(name=>{db[name]=structuredClone(s.records[name]);});
  changeListener('restore');
}
