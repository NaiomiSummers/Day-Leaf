import {toBase64,fromBase64,validateSnapshot} from './store.js';
const rounds=600000;
async function keyFor(password,salt,usage) {
  const material=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveKey']);
  return crypto.subtle.deriveKey({name:'PBKDF2',hash:'SHA-256',salt,iterations:rounds},material,{name:'AES-GCM',length:256},false,[usage]);
}
export async function encryptBackup(data,password) {
  if(password.length<12) throw Error('Use a backup password with at least 12 characters.');
  const salt=crypto.getRandomValues(new Uint8Array(16)), iv=crypto.getRandomValues(new Uint8Array(12));
  const bytes=new TextEncoder().encode(JSON.stringify(data));
  const key=await keyFor(password,salt,'encrypt');
  const cipher=await crypto.subtle.encrypt({name:'AES-GCM',iv},key,bytes);
  return JSON.stringify({format:'dayleaf-encrypted',version:1,kdf:'PBKDF2-SHA256',iterations:rounds,cipher:'AES-256-GCM',salt:toBase64(salt),iv:toBase64(iv),data:toBase64(new Uint8Array(cipher))});
}
export async function decryptBackup(text,password) {
  try {
    const e=JSON.parse(text);
    if(e.format!=='dayleaf-encrypted' || e.version!==1 || e.iterations!==rounds || e.kdf!=='PBKDF2-SHA256' || e.cipher!=='AES-256-GCM') throw Error();
    const salt=fromBase64(e.salt),iv=fromBase64(e.iv);
    if(salt.length!==16 || iv.length!==12) throw Error();
    const key=await keyFor(password,salt,'decrypt');
    const bytes=await crypto.subtle.decrypt({name:'AES-GCM',iv},key,fromBase64(e.data));
    return validateSnapshot(JSON.parse(new TextDecoder().decode(bytes)));
  } catch {
    throw Error('Could not open this backup. Check the password and that the file is a complete Dayleaf backup.');
  }
}
