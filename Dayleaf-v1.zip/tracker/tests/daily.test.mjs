import assert from 'node:assert/strict';
import test from 'node:test';
import { getScheduledOn, timeInBedMinutes } from '../daily.js';

test('time in bed follows the actual bedtime and wake dates across midnight', () => {
  assert.equal(timeInBedMinutes('2026-11-17T23:15', '2026-11-18T07:00'), 465);
  assert.equal(timeInBedMinutes('2026-11-18T10:05', '2026-11-18T10:35'), 30);
});

test('an absent, reversed or invalid interval has no computed duration', () => {
  for (const pair of [
    ['', '2026-11-18T07:00'],
    ['2026-11-17T23:15', ''],
    ['2026-11-18T23:15', '2026-11-18T07:00'],
    ['2026-11-18T07:00', '2026-11-18T07:00'],
    ['invalid', '2026-11-18T07:00']
  ]) assert.equal(timeInBedMinutes(...pair), null);
});

const initial = {
  id: 'fictional-version-one', medId: 'fictional-plan', date: '2026-11-10',
  name: 'Fictional medicine A', dose: 'Original fictional dose', time: '20:00',
  active: true, weekdays: [1, 3, 5], sequence: 1
};
const revised = {
  ...initial, id: 'fictional-version-two', date: '2026-11-17',
  time: '21:00', weekdays: [0, 1, 2, 3, 4, 5, 6], sequence: 2
};
const sameDayCorrection = {...revised, id: 'fictional-version-three', time: '22:00', sequence: 3};
const stopped = {...sameDayCorrection, id: 'fictional-version-four', date: '2026-11-20', active: false, sequence: 4};
const changes = [stopped, sameDayCorrection, initial, revised];

test('schedules respect effective dates and the selected weekdays', () => {
  assert.deepEqual(getScheduledOn('2026-11-09', changes), []);
  assert.deepEqual(getScheduledOn('2026-11-11', changes), [initial]); // Wednesday
  assert.deepEqual(getScheduledOn('2026-11-12', changes), []); // Thursday
});

test('same-date changes use the newest revision; stopping preserves past dates', () => {
  const original = structuredClone(changes);
  assert.deepEqual(getScheduledOn('2026-11-17', changes), [sameDayCorrection]);
  assert.deepEqual(getScheduledOn('2026-11-19', changes), [sameDayCorrection]);
  assert.deepEqual(getScheduledOn('2026-11-20', changes), []);
  assert.deepEqual(getScheduledOn('2026-11-11', changes), [initial]);
  assert.deepEqual(changes, original);
});

test('two daily dose times are independent schedule slots', () => {
  const second = {...initial, id: 'morning-v1', medId: 'morning-plan', time: '08:00'};
  assert.deepEqual(getScheduledOn('2026-11-11', [...changes, second]), [second, initial]);
  assert.deepEqual(getScheduledOn('2026-11-20', [...changes, second]), [second]);
});
