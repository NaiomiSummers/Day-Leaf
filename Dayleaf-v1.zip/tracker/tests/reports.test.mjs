import assert from 'node:assert/strict';
import { test } from 'node:test';
import { rangeData, reportHtml, summary } from '../review.js';

const start = '2026-01-01';
const end = '2026-01-03';
const db = {
  daily: [
    { date:'2025-12-31', reflection:'Outside before' },
    { date:start, updatedAt:'2026-02-11', anxiety:1, dayKind:'Better day',
      sleep:{estimatedMinutes:0,awakenings:0}, activities:{school:{status:'Done',minutes:40,breaks:'One fictional break',help:'Example prompt'}},
      substances:{alcohol:{status:'None'}} },
    { date:'2026-01-02', depression:null, sleep:{estimatedMinutes:null}, activities:{school:{status:'Not logged'}} },
    { date:end, depression:10, dayKind:'Harder day', sleep:{estimatedMinutes:480},
      activities:{work:{status:'Partly done',minutes:20,barrier:'Example noise'}},
      prns:[{name:'Fictional PRN',effect:'Example effect'}], substances:{thc:{status:'Used'}} },
    {date:'2026-01-04',reflection:'Outside after'}
  ],
  meds:[{id:'fake',date:'2026-01-02',name:'Fictional scheduled medication',active:false}],
  weekly:[{date:'2026-01-02',phq:Array(9).fill(3),gad:[0,null,0,0,0,0,0]}],
  cssrs:[{id:'example',date:'2026-01-02',status:'completed',formKey:'recent',version:'Example form',method:'worksheet',
    answers:{q1:'no',q2:'no',q3:'yes',q6:'yes',q6recent:'no'},note:'Private example note'}],
  workbook:[{id:'sheet',date:end,type:'dear',answers:{describe:'Private example description',rehearse:'<Fictional rehearsal>'}}]
};

test('range counts use inclusive activity dates, account for gaps and validate leap dates', () => {
  const range = rangeData(db,start,end);
  assert.equal(range.total,3);
  assert.deepEqual(range.days.map(d=>d.date),[start,end]);
  assert.equal(rangeData(db,end,end).total,1);
  assert.equal(rangeData(db,end,start),null);
  assert.equal(rangeData(db,'2026-02-30','2026-03-10'),null);
  assert.equal(rangeData(db,'2024-02-28','2024-03-01').total,3);
});

test('doctor report keeps incomplete scales, unknown substance data and observed numerical zeros distinct', () => {
  const report = reportHtml(db,'doctor',start,end);
  for (const text of ['27 / 27','Incomplete (6/7 answered)','0m','4h','Example effect','Discontinued','Unknown','2 / 3','1 / 10','10 / 10']) {
    assert.ok(report.includes(text),text);
  }
  assert.match(report,/<th scope="row">Alcohol<\/th><td>0<\/td><td>1<\/td><td>2<\/td><td>3<\/td>/);
  assert.match(report,/<th scope="row">THC<\/th><td>1<\/td><td>0<\/td><td>2<\/td><td>3<\/td>/);
  for (const text of ['Outside before','Outside after','Example form','Private example','Fictional rehearsal']) {
    assert.ok(!report.includes(text),text);
  }
});

const selected = new Set(['dbt-sheet/rehearse','cssrs-example/q6','cssrs-example/q3']);

test('doctor report includes only selected fields and records, respects branching and escapes text', () => {
  const report = reportHtml(db,'doctor',start,end,selected);
  for (const text of ['&lt;Fictional rehearsal&gt;','Example form','Item 6 response']) assert.ok(report.includes(text),text);
  for (const text of ['<Fictional rehearsal>','Item 3 response','Private example']) assert.ok(!report.includes(text),text);
  const nextDay = reportHtml(db,'doctor','2026-01-04','2026-01-04',selected);
  assert.ok(!nextDay.includes('Fictional rehearsal') && !nextDay.includes('Example form'));
});

test('CDR includes dated daily function and changes while excluding assessment and workbook opt-ins', () => {
  const report = reportHtml(db,'cdr',start,end,selected);
  for(const text of ['Better day','Harder day','One fictional break','Example prompt','Example noise','Paid work','Schoolwork','40','20','Partial check-ins','SSDI CDR Function Summary','2 of 3 days logged','Discontinued']) {
    assert.ok(report.includes(text),text);
  }
  for(const text of ['Private example','Example form','Fictional rehearsal','Outside before','Outside after','Example effect']) {
    assert.ok(!report.includes(text),text);
  }
});

test('weekly review shows seven-day coverage and uses separate work, activity, and substance fields', () => {
  const html = summary({db},'2025-12-29','2026-01-04');
  for(const text of ['THC','Alcohol','Scheduled and PRN','Example prompt','Fictional scheduled medication','Schoolwork','Paid work','Hygiene','4 / 7']) {
    assert.ok(html.includes(text),text);
  }
});
