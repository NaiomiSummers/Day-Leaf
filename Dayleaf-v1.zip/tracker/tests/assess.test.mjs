import { test } from "node:test";
import assert from "node:assert/strict";
import {
  changeCssrsAnswer, cssrsComplete, cssrsNeedsSupport, openCssrs,
  phqNeedsSupport, previousCssrs, requiredCssrs, scoreAnswers
} from "../assess.js";

for (const count of [9, 7]) {
  test(`${count}-item measure scores all valid boundaries without an impact item`, () => {
    assert.equal(scoreAnswers(Array(count).fill(0), count), 0);
    assert.equal(scoreAnswers(Array(count).fill(3), count), 3 * count);
    const middle = Array.from({length: count}, (_, i) => i % 4);
    assert.equal(scoreAnswers(middle, count), middle.reduce((a, b) => a + b, 0));
  });
  test(`${count}-item measure leaves omitted or invalid inputs incomplete`, () => {
    for (const value of [null, undefined, "", false, "0", NaN, -1, 4, 1.5]) {
      const values = Array(count).fill(3);
      values[1] = value;
      assert.equal(scoreAnswers(values, count), null);
    }
    assert.equal(scoreAnswers(Array(count), count), null);
    assert.equal(scoreAnswers(Array(count - 1).fill(0), count), null);
    assert.equal(scoreAnswers(Array(count + 1).fill(0), count), null);
  });
}

test("PHQ item 9 triggers support with an incomplete, low, or maximum symptom total", () => {
  for (const response of [1, 2, 3]) {
    for (const other of [null, 0, 3]) {
      const items = Array(9).fill(other);
      items[8] = response;
      assert.equal(phqNeedsSupport(items), true);
    }
  }
  for (const response of [0, null, undefined]) {
    const items = Array(9).fill(3);
    items[8] = response;
    assert.equal(phqNeedsSupport(items), false);
  }
});

test("first assessment uses Recent and does not generate a record on opening", () => {
  const records = [];
  const first = openCssrs(records, "2026-05-01");
  assert.equal(first.formKey, "recent");
  assert.equal(first.priorDate, "");
  assert.equal(first.status, null);
  assert.deepEqual(first.answers, {});
  assert.equal(records.length, 0);
});

test("a gap or incomplete screen never becomes the next reference date", () => {
  const rows = [
    { date: "2026-05-01", status: "completed", time: "09:00" },
    { date: "2026-05-02", status: "incomplete" },
    { date: "2026-05-05", status: null },
    { date: "2026-05-12", status: "completed" }
  ];
  const next = openCssrs(rows, "2026-05-10");
  assert.equal(previousCssrs(rows, "2026-05-10"), rows[0]);
  assert.equal(next.formKey, "followup");
  assert.equal(next.priorDate, "2026-05-01");
  assert.equal(next.priorTime, "09:00");
  assert.deepEqual(next.answers, {});
  assert.equal(openCssrs(rows.slice(1), "2026-05-10").formKey, "recent");
});

test("backdating preserves the form and timeframe of a historical screen", () => {
  const baseline = {...openCssrs([], "2026-05-03"), status: "completed"};
  const followup = {...openCssrs([baseline], "2026-05-09"), status: "completed"};
  const earlier = {...openCssrs([], "2026-05-01"), status: "completed"};
  const middle = {...openCssrs([earlier, baseline], "2026-05-07"), status: "completed"};
  const rows = [earlier, baseline, middle, followup];
  assert.equal(openCssrs(rows, baseline.date).formKey, "recent");
  assert.equal(openCssrs(rows, followup.date).priorDate, baseline.date);
  const draft = openCssrs(rows, followup.date);
  draft.answers.q2 = "yes";
  assert.deepEqual(followup.answers, {});
});

for (const key of ["recent", "followup"]) {
  test(`${key} always requires the behavior item and follows both Q2 branches`, () => {
    assert.deepEqual(requiredCssrs(key, {}), ["q1", "q2", "q6"]);
    const short = {q1: "no", q2: "no"};
    assert.equal(cssrsComplete(key, short), false);
    assert.equal(cssrsComplete(key, {...short, q6: "no"}), true);
    const full = {q1: "no", q2: "yes", q3: "no", q4: "no", q5: "no", q6: "no"};
    assert.deepEqual(requiredCssrs(key, full), ["q1", "q2", "q3", "q4", "q5", "q6"]);
    assert.equal(cssrsComplete(key, full), true);
    for (const item of requiredCssrs(key, full)) {
      assert.equal(cssrsComplete(key, {...full, [item]: ""}), false);
    }
  });
}

test("Recent behavior requires the past-three-months follow-up only after Q6 Yes", () => {
  const values = {q1: "no", q2: "no", q6: "yes"};
  assert.deepEqual(requiredCssrs("recent", values), ["q1", "q2", "q6", "q6recent"]);
  assert.equal(cssrsComplete("recent", values), false);
  assert.equal(cssrsComplete("recent", {...values, q6recent: "no"}), true);
  assert.equal(cssrsComplete("recent", {...values, q6recent: "yes"}), true);
  assert.equal(cssrsComplete("followup", values), true);
  assert.ok(!requiredCssrs("followup", values).includes("q6recent"));
});

test("editing branch answers removes inapplicable responses and preserves unrelated items", () => {
  const full = {q1: "no", q2: "yes", q3: "yes", q4: "no", q5: "no", q6: "yes", q6recent: "no"};
  const short = changeCssrsAnswer("recent", full, "q2", "no");
  assert.deepEqual(short, {q1: "no", q2: "no", q6: "yes", q6recent: "no"});
  assert.deepEqual(changeCssrsAnswer("recent", short, "q6", "no"), {q1: "no", q2: "no", q6: "no"});
  assert.equal(cssrsComplete("recent", changeCssrsAnswer("recent", short, "q2", "yes")), false);
  assert.deepEqual(changeCssrsAnswer("recent", short, "q5", "yes"), short);
  assert.equal(full.q3, "yes");
});

test("any applicable yes or explicitly requested support surfaces the plan without scoring", () => {
  for (const formKey of ["recent", "followup"]) {
    for (const answers of [{q1:"yes"}, {q2:"yes"}, {q2:"no", q6:"yes"}, {q2:"yes", q5:"yes"}]) {
      assert.equal(cssrsNeedsSupport({method:"worksheet", formKey, answers}), true);
    }
    assert.equal(cssrsNeedsSupport({method:"worksheet", formKey, answers:{}}), false);
    assert.equal(cssrsNeedsSupport({method:"worksheet", formKey, answers:{q2:"no", q3:"yes"}}), false);
  }
  assert.equal(cssrsNeedsSupport({method:"manual", concern:true}), true);
  assert.equal(cssrsNeedsSupport({method:"manual", concern:null}), false);
});
