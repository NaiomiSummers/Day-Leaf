import {test} from 'node:test';
import assert from 'node:assert/strict';
import {encryptBackup,decryptBackup} from '../backup.js';
import {validateSnapshot,stores} from '../store.js';

const at='2026-01-09T13:00:00.000Z';
const example={app:'Dayleaf',schema:1,exportedAt:at,records:Object.fromEntries(stores.map(k=>[k,[]]))};
example.records.daily=[{id:'2026-01-08',date:'2026-01-08',reflection:'Fictional journal example',createdAt:at,updatedAt:at}];
const password='synthetic-test-password';
test('encrypted backup round trips every store without exposing note text',async()=>{
  const a=await encryptBackup(example,password);
  const b=await encryptBackup(example,password);
  assert.ok(!a.includes('Fictional journal example'));
  assert.notEqual(JSON.parse(a).salt,JSON.parse(b).salt);
  assert.notEqual(JSON.parse(a).iv,JSON.parse(b).iv);
  assert.deepEqual(await decryptBackup(a,password),example);
});
test('wrong password, altered ciphertext, malformed backup and unsupported format fail',async()=>{
  const text=await encryptBackup(example,password);
  await assert.rejects(decryptBackup(text,'an incorrect password'));
  const e=JSON.parse(text);e.data=(e.data[0]==='A'?'B':'A')+e.data.slice(1);
  await assert.rejects(decryptBackup(JSON.stringify(e),password));
  await assert.rejects(decryptBackup(text.slice(3),password));
  await assert.rejects(encryptBackup(example,'short'));
  assert.throws(()=>validateSnapshot({...example,schema:99}));
});
test('restore rejects missing stores and duplicate records before replacing data',()=>{
  assert.throws(()=>validateSnapshot({...example,records:{daily:[]}}));
  const records={...example.records,daily:[...example.records.daily,...example.records.daily]};
  assert.throws(()=>validateSnapshot({...example,records}));
});
