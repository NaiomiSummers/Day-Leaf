# Dayleaf

Dayleaf is a private, offline-first journal for daily functioning, medical appointments and patient-reported CDR documentation. The app starts empty. It contains all seven screens, the two supplied blank Columbia forms, the PHQ-9 and GAD-7 questionnaires, and six editable DBT worksheets. Once offline setup finishes, every form, answer control, report preview and backup operation works locally.

## Start on Windows

1. Extract the ZIP. Open the folder containing `serve.mjs` in PowerShell.
2. Install Node.js 24 LTS or later if needed. The server uses Node's built-in modules. There is no package-install or build step. [Node.js for Windows](https://nodejs.org/en/download/)
3. Run the command below. Open [Dayleaf on this PC](http://127.0.0.1:4173/) and look for **Ready for offline use** in the sidebar or in Settings. Leave PowerShell open for development. Press Ctrl+C to stop the server.

```powershell
node .\serve.mjs
```

Use the same browser, address and port when reopening your journal. A different origin has its own IndexedDB database. Double-clicking the HTML file cannot install the service worker. Windows loopback addresses work for development. An iPhone accessing a PC over Wi-Fi needs trusted HTTPS. [Service-worker requirements](https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API/Using_Service_Workers)

## Install on an iPhone with local HTTPS

The PC serves the app files over your private Wi-Fi during installation. Journal entries stay in the browser or installed app where you enter them. You can stop the server once the **Home Screen copy** is ready for offline use.

### 1. Make a certificate for your PC's private address

Connect both devices to the same private Wi-Fi. Run `ipconfig` on the PC and find the IPv4 address of the adapter connected to that network. Reserve that address in your router if you want to keep the same journal origin. Use a current iPhone Safari with support for service workers, Web Crypto and native dialogs.

Install `mkcert` for Windows using the project's instructions and open a new PowerShell window in the extracted app folder. Replace the sample IP address below with your PC's actual address. Keep the generated key files in a private folder outside the app. [mkcert installation and mobile-device guide](https://github.com/FiloSottile/mkcert)

```powershell
$lanAddress = '192.168.1.42'
$certFolder = Join-Path $env:LOCALAPPDATA 'Dayleaf-dev-certs'
New-Item -ItemType Directory -Force -Path $certFolder | Out-Null
$siteCert = Join-Path $certFolder 'dayleaf.pem'
$siteKey = Join-Path $certFolder 'dayleaf-key.pem'
mkcert -install
mkcert -cert-file $siteCert -key-file $siteKey $lanAddress localhost 127.0.0.1
$publicRoot = Join-Path (mkcert -CAROOT) 'rootCA.pem'
```

### 2. Trust your development certificate on your phone

Run the following temporary transfer command in the same PowerShell window. It serves the **public certificate only** and prints its SHA-256 fingerprint. Keep the root private key and the site's private key on your PC.

```powershell
node .\serve.mjs --ca-only $publicRoot --host $lanAddress --port 4174
```

1. Open the printed `http://…:4174/root.cer` address in iPhone Safari. If Windows prompts for network access, allow Node on your private network. A guest Wi-Fi network with device isolation can prevent the phone from reaching the PC.
2. Allow the certificate profile to download. Open **Settings → Profile Downloaded** or **General → VPN & Device Management**, inspect your local certificate, then tap **Install**. Confirm it is the certificate from your PC before trusting it.
3. Go to **Settings → General → About → Certificate Trust Settings** and enable full trust for that development root. On Windows, press Ctrl+C to stop certificate transfer. [Apple certificate trust instructions](https://support.apple.com/en-us/102390)

### 3. Add Dayleaf to the Home Screen

Run this in the same PowerShell window.

```powershell
node .\serve.mjs --host $lanAddress --port 4173 --cert $siteCert --key $siteKey
```

1. Open the printed **HTTPS** address in Safari and check that it opens without a certificate warning. If it fails, check the exact IP address in the certificate, root trust, Wi-Fi and Windows private-network firewall permission.
2. Tap **Share → Add to Home Screen**. Depending on Safari's toolbar layout, Share is in the page menu. Enable **Open as Web App** if offered, then tap **Add**. [Apple's Home Screen instructions](https://support.apple.com/guide/iphone/open-as-web-app-iphea86e5236/ios)
3. Open **Dayleaf from its new icon while still connected**. Go to **More → Settings** and wait for **Ready for offline use**. Begin with a fictional entry in this installed copy. Safari and a Home Screen app can have separate storage.
4. Turn on Airplane Mode, switch off Wi-Fi, close Dayleaf and reopen its icon. Check that your fictional entry and the blank forms open. Now the PC can be offline. Keep an encrypted backup before changing the address, reinstalling or clearing storage.

## Everyday use

- **Today.** Tap the date at the top to open another activity date. Select either symptom rating independently. Tap a selected rating again to clear it. Expand only the sections you want. Edits save as a draft. **Save check-in** accepts partial entries. History reopens them. Activity dates and original creation/last-edit timestamps are stored separately.
- **Sleep and function.** Enter the actual bedtime and waking dates for an overnight interval. The app calculates time in bed. An optional control copies that duration into estimated sleep, which you can correct separately. Each hygiene, school and paid-work activity has its own status and optional duration, breaks, help, accommodations and barriers.
- **Medications.** Add a scheduled dose time under Medications with its effective date and recurring days. Use **Record change** or record a stop when the schedule changes. Saved dose logs keep their names, doses, times and statuses. Log a PRN separately under Today with the amount actually taken and any effects.
- **Reminders.** On your iPhone, create a generic scheduled-dose reminder such as “Scheduled routine.” In its details, set Date, Time and Repeat to match your existing schedule. Create a separate “Daily check-in” reminder. The phone's Reminders app delivers these alerts. Dose status changes only when you enter it in Dayleaf. PRN logging has no alert or dose suggestion. The same instructions are available offline under Medications. [Apple Reminders](https://support.apple.com/guide/iphone/iphec7a1de82/ios)
- **Weekly Review.** Open it weekly from Today. The activity review covers seven calendar days and shows gaps. The PHQ-9 and GAD-7 each cover two weeks, so questionnaires taken seven days apart overlap by seven days. Partial questionnaires show the count answered. Functional-impact answers are stored separately from totals.
- **DBT Workbook.** Choose Behavior Chain Analysis, DEAR MAN, DBT Diary Card, Check the Facts, Opposite Action, or Pros & Cons. Enter any part, change the worksheet date, add chain links and optionally link an existing daily check-in. Drafts and finished worksheets stay editable.
- **Safety plan.** In Settings, save your clinician-agreed steps and contacts. **Safety plan** stays available throughout the journal. An applicable Yes on the C-SSRS or any nonzero PHQ-9 item 9 makes support immediately accessible while you continue editing. Calling a contact requires a tap. Nobody monitors this app. It is not an emergency response tool.

## The offline Columbia forms

Open **Today → C-SSRS safety screen**. Both original, user-supplied PDFs and their question text are bundled. There is no import step. The personal answer sheet puts the applicable original questions and examples next to Yes/No controls. The complete PDF opens from the screen. You can also record a paper completion without entering the individual answers.

The first recorded screen uses **Recent**. Items 1–5 use the past month. Item 6 asks about lifetime behavior. A Yes to item 6 adds the past-three-months question. After a previous completed screen, **Since Last Visit** covers the interval since that assessment. If you already have an earlier completed paper screen, enter it under its actual date before starting a follow-up. Both versions include item 6 after either answer to item 2. Changing a branch clears responses that no longer apply. Missing days remain unassessed. Each record keeps its version and previous assessment reference.

Columbia describes use of its tools in community and healthcare settings and electronic health records. Dayleaf pairs the supplied paper forms with a local response record for personal use. Separate validation or endorsement of this software as an electronic C-SSRS implementation has not been established. The app produces no C-SSRS total, risk category or assurance of safety. [Columbia's use guidance](https://cssrs.columbia.edu/the-columbia-scale-c-ssrs/cssrs-for-communities-and-healthcare/) · [Original Recent form](https://cssrs.columbia.edu/wp-content/uploads/C-SSRS-Screener-Self-Report-Recent-2026.pdf) · [Original Since Last Visit form](https://cssrs.columbia.edu/wp-content/uploads/C-SSRS-Screener-Self-Report-Since-Last-Visit-2026.pdf)

Robert L. Spitzer, Janet B.W. Williams, Kurt Kroenke and colleagues developed the PHQ-9 and GAD-7 with an educational grant from Pfizer Inc. The app includes their English items, response choices, two-week stems and functional-impact questions. [PHQ-9 English form](https://www.phqscreeners.com/images/sites/g/files/g10060481/f/201412/PHQ-9_English.pdf) · [GAD-7 English form](https://england.icst.org.uk/wp-content/uploads/2021/06/GAD-7.pdf) · [Authors' scoring and reproduction instructions](https://manual.jointcommission.org/pub/BHCInstruments/RomInstr00054/instructions_PHQ.pdf)

## Reports and backups

**Reports → Doctor Summary** covers symptoms, sleep, assessments, medications, PRNs, substances and treatment changes. C-SSRS and workbook information appears only when you select specific details. **SSDI CDR Function Summary** includes dated activity examples, time, breaks, help, accommodations, barriers and changes. It includes better and harder days when you described them that way. The app does not infer day quality from a symptom score. Both reports identify the information as patient-reported.

1. Set the inclusive activity-date range, choose any optional doctor-report fields, then tap **Preview report**.
2. Read the preview. Changing the type or range clears prior optional selections. Coverage counts include partial days with an observation. Opening a blank entry does not count as a logged day.
3. Tap **Print / Save PDF**. In the iPhone print sheet, open or pinch out the page preview if necessary, then use **Share → Save to Files → On My iPhone** for a local copy. On Windows use the browser's Save as PDF destination. Exported PDFs contain readable sensitive information and have no password protection.

In **Settings → Encrypted backup**, set and confirm a password of 12 or more characters, create the encrypted file, then tap **Save encrypted backup**. Keep both the file and its password somewhere you control. A lost password cannot be recovered. Backups cover daily entries, schedules, assessments, worksheets, safety plans and contacts, including original dates and timestamps. A fresh salt and IV are generated for every backup. The app uses PBKDF2-SHA-256 with 600,000 iterations and AES-256-GCM.

To restore, select the encrypted file, enter the password and tap **Preview restore**. Review the counts before choosing **Replace local records**. Make a backup of the current journal first if you want to keep it. Restore replaces the whole journal in a single IndexedDB transaction. Canceling, a wrong password or a damaged file leaves current records intact.

Entries use the protection of your browser and device. The backup password encrypts the exported file. Clearing website data, removing the app, storage eviction or losing the device can remove journal records. Keep a current encrypted backup. There are no accounts, cloud sync, analytics, third-party fonts, automatic messages or connections to medical records.

## Verification

Run the included tests from the app folder with Node 24 or later.

```powershell
node --test "tests/*.test.mjs"
```

The shipped unit tests cover PHQ-9 and GAD-7 bounds and missing inputs, both C-SSRS branches and timeframes, baseline selection across gaps, backdating, support access, overnight sleep, medication version history, inclusive date ranges, report selections, encrypted round trips and rejected backups.

Additional checks performed on Windows with fictional data and an isolated Edge Chromium profile included the following.

- Verified a blank first run, 44-pixel daily rating targets, independent ratings, partial save/reopen, zero versus missing values, manual sleep corrections, and medication snapshots after a schedule change.
- Completed both clinical questionnaires and the two Columbia versions at a 390 × 844 touch viewport. Verified completion status, behavior branching, item-9 support access and persistence after offline reload.
- Opened all six worksheet templates, edited repeatable chain links, attached a daily record and reopened a dated draft from History.
- Produced both PDFs. Inspected rendered pages and extracted text to verify date filtering, readable tables and exclusion of unselected sensitive details.
- Installed the service worker, loaded both blank PDFs offline, checked a partial-content PDF request, then closed and reopened the journal with networking disabled. The browser test observed no third-party HTTP requests.
- Exported an encrypted backup through Settings, tried a wrong password, canceled replacement, then restored it and compared the recovered data and timestamps. Unit tests also rejected altered ciphertext.
- Tested HTTPS serving and the certificate-only transfer using temporary test certificates. No device trust settings were changed during testing.

### Actual iPhone checklist — still to verify

Use fictional data and a disposable install for these checks.

- [ ] Install from Safari on your private Wi-Fi. Open the Home Screen copy, wait for offline readiness, disable Wi-Fi and cellular, close it, and relaunch.
- [ ] Open and zoom both original Columbia PDFs offline. Try both item-2 branches, verify item 6 remains, and check Recent's behavior follow-up. Leave a date blank, then open a later follow-up and verify its previous completion date.
- [ ] Enter and reopen a partial daily draft, a weekly questionnaire and a dated worksheet. Check portrait, landscape, large text, VoiceOver, keyboard focus, Yes/No controls, and return from the safety plan.
- [ ] Use a fictional nonzero PHQ-9 item 9 while other answers are blank. Confirm support opens immediately and the questionnaire remains incomplete. Complete 0/27 and 27/27 PHQ-9 cases and 0/21 and 21/21 GAD-7 cases.
- [ ] Try an overnight sleep interval and manual estimate. Record one schoolwork entry and a separate paid-work entry. Check a schedule change against a previously logged dose.
- [ ] Preview both report types. Save each using the iOS print sheet, open it in Files, inspect page breaks and verify dates and optional details.
- [ ] Export an encrypted file to On My iPhone. Test wrong-password handling and restore into an empty, disposable copy. Compare daily logs, assessments, worksheet links, safety contacts and timestamps.
- [ ] Set a generic scheduled-dose reminder and a separate check-in reminder in Apple's app. Confirm that delivery leaves dose status unchanged.

## Developing the app

The server only serves the app's allowlisted files. `app.js` handles navigation, `store.js` handles IndexedDB and `backup.js` handles encryption. Daily and medication screens live in `daily.js`, assessments in `assess.js`, and workbook/history/reports in `review.js`. The original forms and their accessible display data are under `forms/`. All styling and imagery are local.

Use one editor window per journal. A revision check stops a stale window from overwriting a newer save. If you change cached files, bump the version in `sw.js`. For new assets, update both the service-worker list and server allowlist. Close all open copies, then reopen while the PC is serving the updated files. Use a separate development origin or a disposable browser profile to test updates with fictional records.

The header uses a local raster illustration generated with the built-in ImageGen tool. Its brief was a quiet, mint-and-forest woodblock landscape with a river, conifers, a pale golden sun and open space on the left. The optimized app asset is `assets/hills.webp`.

