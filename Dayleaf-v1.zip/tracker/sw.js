// Bump the version whenever an application file changes.
const prefix='dayleaf-static-'+new URL(self.registration.scope).pathname+'-';
const cacheName=prefix+'v1.0.0-final';
const assets=['./','./index.html','./style.css','./app.js','./icons.js','./store.js','./backup.js','./settings.js','./daily.js','./daily.css','./review.js','./review.css','./assess.js','./assess.css','./manifest.webmanifest','./forms/recent.pdf','./forms/followup.pdf','./forms/recent.png','./forms/followup.png','./forms/passages.js','./assets/hills.webp','./assets/icon-192.png','./assets/icon-512.png','./assets/touch.png'];
self.addEventListener('install',event=>{
  event.waitUntil(caches.open(cacheName).then(cache=>cache.addAll(assets.map(url=>new Request(url,{cache:'reload'})))));
});
self.addEventListener('activate',event=>{
  event.waitUntil((async()=>{
    const keys=await caches.keys();
    await Promise.all(keys.filter(k=>k.startsWith(prefix)&&k!==cacheName).map(k=>caches.delete(k)));
    await self.clients.claim();
  })());
});
self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET' || !event.request.url.startsWith(self.registration.scope))return;
  event.respondWith((async()=>{
    const cache=await caches.open(cacheName);
    const match=await cache.match(event.request,{ignoreSearch:true});
    if(match){
      // Native PDF readers can request a byte range when reopening a cached document.
      const range=event.request.headers.get('Range');
      if(range && new URL(event.request.url).pathname.endsWith('.pdf')){
        const bytes=await match.arrayBuffer(), pair=/^bytes=(\d+)-(\d*)$/.exec(range);
        if(pair){
          const start=Number(pair[1]),end=pair[2]?Math.min(Number(pair[2]),bytes.byteLength-1):bytes.byteLength-1;
          if(start>end)return new Response(null,{status:416,headers:{'Content-Range':'bytes */'+bytes.byteLength}});
          return new Response(bytes.slice(start,end+1),{status:206,headers:{'Content-Type':'application/pdf','Accept-Ranges':'bytes','Content-Range':'bytes '+start+'-'+end+'/'+bytes.byteLength,'Content-Length':String(end-start+1)}});
        }
      }
      return match;
    }
    return fetch(event.request);
  })());
});

