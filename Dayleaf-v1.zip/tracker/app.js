import {db,put,openStore} from './store.js';
import {icon,mark} from './icons.js';
import {renderToday,renderMedications} from './daily.js';
import {renderWeekly,renderCssrs,scoreAnswers} from './assess.js';
import {renderHistory,renderReports,renderWorkbook,summary,rangeData} from './review.js';
import {renderSettings,showSafety} from './settings.js';

const $ = selector=>document.querySelector(selector);
const pages={
  today:['Today','sun',renderToday],
  weekly:['Weekly Review','calendar',renderWeekly,'Review your past seven days and complete the two-week questionnaires.'],
  medications:['Medications','pill',renderMedications,'Manage your scheduled doses and dated treatment changes.'],
  history:['History','history',renderHistory,'Revisit your dated entries and continue a draft.'],
  workbook:['DBT Workbook','book',renderWorkbook,'Practice a skill in a private, dated worksheet.'],
  reports:['Reports','chart',renderReports,'Choose a date range and preview what you want to share.'],
  settings:['Settings','settings',renderSettings,'Manage your safety plan, local storage and encrypted backups.']
};
export const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const localISO=d=>[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');
const today=()=>localISO(new Date());
const dateBefore=(value,days)=>{const d=new Date(value+'T12:00:00');d.setDate(d.getDate()-days);return localISO(d);};
const pretty=value=>new Intl.DateTimeFormat(undefined,{weekday:'long',month:'long',day:'numeric',year:'numeric'}).format(new Date(value+'T12:00:00'));
let screen='today',activeDate=today(),lastScrollFocus=null,offlineStatus='Preparing offline copy',ready=false,toastTimer,opened=false;
const validDate=value=>/^\d{4}-\d{2}-\d{2}$/.test(value) && localISO(new Date(value+'T12:00:00'))===value;
function routeFromUrl(){
  const [page,raw]=location.hash.slice(1).split('/');
  screen=Object.hasOwn(pages,page)?page:'today';
  activeDate=validDate(raw)?raw:today();
}
function go(page,date){
  if(!Object.hasOwn(pages,page))return;
  closeDialog();
  screen=page;activeDate=validDate(date)?date:today();
  const hash='#'+page+(activeDate===today()?'':'/'+activeDate);
  if(location.hash!==hash) history.pushState({},'',hash);
  render();
  window.scrollTo(0,0);
}
function toast(message){
  $('#toast').textContent=message;clearTimeout(toastTimer);
  toastTimer=setTimeout(()=>{$('#toast').textContent='';},3800);
}
function openDialog(title,body){
  const d=$('#dialog');
  if(!d.open)lastScrollFocus=document.activeElement;
  $('#dialog-body').innerHTML='<div class="dialog-header"><h2 id="dialog-title">'+esc(title)+'</h2><button class="icon-btn" data-close aria-label="Close dialog">'+icon('close',18)+'</button></div>'+body;
  d.setAttribute('aria-labelledby','dialog-title');if(!d.open)d.showModal();
  return $('#dialog-body');
}
function closeDialog(){if($('#dialog').open)$('#dialog').close();}
$('#dialog').addEventListener('close',()=>{lastScrollFocus?.focus?.({preventScroll:true});});
const context=()=>({
  root:$('#content'),db,date:activeDate,today,put,go,esc,icon,refresh:render,toast,openDialog,closeDialog,
  setDate:date=>go(screen,date),safety:()=>showSafety(context()),summary:(start,end)=>summary(context(),start,end),
  renderCssrs:(host,date)=>renderCssrs(context(),host,date),offlineStatus:()=>offlineStatus
});
function navLink(key){
  const [label,symbol]=pages[key];return '<button class="nav-link '+(screen===key?'active':'')+'" data-go="'+key+'" '+(screen===key?'aria-current="page"':'')+'>'+icon(symbol)+'<span>'+label+'</span></button>';
}
function nav(){
  $('#rail').innerHTML='<div class="brand">'+mark+'<div><strong>Dayleaf</strong><small>Personal journal</small></div></div><nav aria-label="Main"><div class="nav-group">My journal</div><div class="nav-list">'+['today','weekly','medications','history'].map(navLink).join('')+'</div><div class="nav-group">Tools</div><div class="nav-list">'+['workbook','reports'].map(navLink).join('')+'</div></nav><div class="rail-bottom">'+navLink('settings')+'<div class="offline-box"><span class="status-dot" data-status-dot></span><span data-offline-status></span></div></div>';
  $('#breadcrumb').innerHTML='<span class="crumb">'+icon('book',16)+' My journal <span class="divider">/</span><strong>'+pages[screen][0]+'</strong></span><span class="mobile-brand">'+mark+'Dayleaf</span>';
  $('#top [data-safety]').innerHTML=icon('heart',16)+'Safety plan';
  $('#mobile-nav').innerHTML=[['today','Today','sun'],['weekly','Weekly','calendar'],['history','History','history'],['more','More','menu']].map(([k,l,i])=>{
    const active=k==='more'?!['today','weekly','history'].includes(screen):screen===k;
    return '<button class="mobile-tab '+(active?'active':'')+'" '+(k==='more'?'data-more aria-haspopup="dialog"':'data-go="'+k+'"')+(active?' aria-current="page"':'')+'>'+icon(i,20)+l+'</button>';}).join('');
  updateStatus();
}
function dateButton(){
  return '<button class="hero-date" data-date aria-label="Change activity date, '+esc(pretty(activeDate))+'">'+icon('calendar',16)+esc(pretty(activeDate))+icon('chevron',12)+'</button>';
}
function tiles(){
  const area=$('#metrics');
  if(screen!=='today'){area.innerHTML='';return;}
  const current=db.daily.find(d=>d.date===activeDate);
  const seven=rangeData(db,dateBefore(activeDate,6),activeDate);
  const lastReview=[...seven.weekly].sort((a,b)=>b.date.localeCompare(a.date))[0];
  const completed=lastReview && scoreAnswers(lastReview.phq,9)!==null && scoreAnswers(lastReview.gad,7)!==null;
  const values=[
    ['clipboard','', 'Daily entry',current?(current.status==='saved'?'Saved':'Draft saved'):'Not started',''],
    ['bars','ochre','Days logged',seven.days.length+' of 7 days','history'],
    ['book','mauve','Weekly review',lastReview?(completed?'View review':'Continue review'):'Start review','weekly']
  ];
  area.innerHTML=values.map(([i,color,label,value,target])=>{
    const tag=target?'button':'div';return '<'+tag+' class="metric '+(target?'button':'')+'" '+(target?'data-tile="'+target+'"':'')+'><span class="tile-icon '+color+'">'+icon(i,22)+'</span><span><span class="label">'+label+'</span><b>'+value+'</b></span>'+(target?icon('chevron',13):'')+'</'+tag+'>';
  }).join('');
  const review=area.querySelector('[data-tile="weekly"]');review.onclick=()=>go('weekly',lastReview?.date || activeDate);
  area.querySelector('[data-tile="history"]').onclick=()=>go('history',activeDate);
}
function render(){
  if(!opened)return;
  nav();
  $('#page-head').innerHTML= screen==='today'?
    '<div class="hero">'+dateButton()+'<h1>'+(activeDate===today()?'Today’s check-in':'Daily check-in')+'</h1><p>Log what you can. Your draft saves as you go.</p></div>':
    '<div class="screen-heading">'+(screen==='weekly'?dateButton():'')+'<h1>'+pages[screen][0]+'</h1><p>'+pages[screen][3]+'</p></div>';
  tiles();
  $('#content').replaceChildren();
  pages[screen][2](context());
  updateStatus();
  $('#foot').innerHTML=icon('lock',13)+'Stored on this device';
  document.title=pages[screen][0]+' · Dayleaf';
}
function showError(e){
  const area=$('#failure');area.hidden=false;area.textContent=e?.message||'The journal could not save. Keep this window open and check available storage.';
}
document.addEventListener('click',event=>{
  const el=event.target.closest('button,a');
  if(!el)return;
  if(el.classList.contains('skip')){
    event.preventDefault();
    $('#content').focus();
    return;
  }
  if(el.hasAttribute('data-go'))go(el.dataset.go);
  else if(el.hasAttribute('data-close'))closeDialog();
  else if(el.hasAttribute('data-safety'))showSafety(context());
  else if(el.hasAttribute('data-more'))openDialog('My journal','<nav class="nav-list">'+Object.keys(pages).map(navLink).join('')+'</nav>');
  else if(el.hasAttribute('data-date')){
    const dialog=openDialog(screen==='weekly'?'Review date':'Activity date','<form class="stack" data-date-form><label class="field">Date<input type="date" required value="'+activeDate+'" max="'+today()+'"></label><div class="row"><button type="submit" class="btn primary">Open date</button><button type="button" class="btn" data-go="'+screen+'">Go to today</button></div></form>');
    dialog.querySelector('form').onsubmit=e=>{e.preventDefault();go(screen,dialog.querySelector('input').value);};
  }
});
window.addEventListener('popstate',()=>{closeDialog();routeFromUrl();render();});
function updateStatus(){
  document.querySelectorAll('[data-offline-status]').forEach(el=>el.textContent=offlineStatus);
  document.querySelectorAll('[data-status-dot]').forEach(el=>el.classList.toggle('ready',ready));
}
async function startOffline(){
  try{
    if(!('serviceWorker' in navigator))throw Error();
    const registration=await navigator.serviceWorker.register('./sw.js');
    const worker=registration.installing;
    worker?.addEventListener('statechange',()=>{if(worker.state==='redundant' && !registration.active){offlineStatus='Offline setup failed';updateStatus();}});
    await navigator.serviceWorker.ready;
    ready=true;offlineStatus='Ready for offline use';updateStatus();
  }catch{offlineStatus='Offline setup unavailable';updateStatus();}
}
try{
  if(!window.isSecureContext || !window.indexedDB || !crypto.subtle)throw Error('Open Dayleaf through localhost on Windows or trusted HTTPS on iPhone. See the setup guide.');
  await openStore(()=>tiles(),showError);
  opened=true;routeFromUrl();render();startOffline();
}catch(e){showError(e);}

